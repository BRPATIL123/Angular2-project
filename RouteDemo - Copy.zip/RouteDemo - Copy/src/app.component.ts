//1.import the required Components/Decorators or members of a module
import {Component} from "angular2/core"
import {ROUTER_DIRECTIVES,RouteConfig} from "angular2/router"

import {HomeComponent} from "./home.component"
import {PlayListComponent} from "./playlist.component"
import {ManageComponent} from "./manage.component"

//@Component and the followed Class are single Component Defination
//START
    //2.Metadata (Decorator)
    @Component({
        //HTML tag selector
        selector:"myroute-app",
        directives:[ROUTER_DIRECTIVES],
        //actual HTML script to render
        template:`<h1>Routing Demo</h1>
        <a href="" [routerLink]="['/Home']"> HOME PAGE |</a>
        <a href="" [routerLink]="['/PlayList']"> PLAYLIST PAGE |</a>
        <a href="" [routerLink]="['/Manage']"> MANGE PAGE |</a>

        <hr>

        <div>
            <router-outlet></router-outlet>
        </div>
        `
    }) // this component is not stand alone and must followed by a class else Error.
    //     <router-outlet> is a builn in directive defined in [ROUTER_DIRECTIVES]

@RouteConfig([
    {path:"/home",name:"Home",component:HomeComponent,useAsDefault:true},
    {path:"/playlist",name:"PlayList",component:PlayListComponent},
    {path:"/manage",name:"Manage",component:ManageComponent},
])

    //3.Defined a class for Component
  export class AppComponent{
        
    }
//END

