import {Component} from "angular2/core"

@Component({
    template:`<h3>My Play List</h3>`
})

export class PlayListComponent{
    
}