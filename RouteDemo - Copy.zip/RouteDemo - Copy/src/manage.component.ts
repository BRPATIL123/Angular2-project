import {Component} from "angular2/core"

@Component({
    template:`<h3>Manage Playlist</h3>`
})

export class ManageComponent{
    
}