import {Component} from "angular2/core"

@Component({
    template:`<h3>Welcome to my website home</h3>`
})

export class HomeComponent{
    
}